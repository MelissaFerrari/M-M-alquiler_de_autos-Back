package AgenciaAutros.AgenciaAutos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgenciaAutosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgenciaAutosApplication.class, args);
	}

}
